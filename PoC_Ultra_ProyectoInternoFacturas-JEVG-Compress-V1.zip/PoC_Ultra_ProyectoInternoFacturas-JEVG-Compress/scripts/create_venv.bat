@echo off
python -m venv .venv
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\pip.exe install -r requirements.txt
echo Entorno listo. Active con: .venv\Scripts\activate

