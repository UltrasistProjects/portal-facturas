"""Consultas de persistencia reutilizables."""

